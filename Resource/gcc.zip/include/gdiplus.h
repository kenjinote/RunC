#include "gdiplus/gdiplus.h"
